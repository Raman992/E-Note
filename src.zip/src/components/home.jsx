import React from 'react'
import Notes from './notes'
import Addnote from './addnote'

export const Home = () => {

    return (
        <div>
            <Addnote/>
            <Notes/>
        </div>
    )
}
export default Home
